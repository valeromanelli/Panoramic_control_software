from ad5361_commands import ad5361
import socket
import json


def communicate_with_board(command):
    board = ad5361()

    response = []
    for channel in command.keys():
        try:
            result = board.Write_Voltage(command[channel], int(channel))
            board.Pulse_LDAC()
            response.append(result)
        except Exception:
            response.append(-1)

    return response


def server_program():
    host = '127.0.0.1'
    port = 65432

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(1)

    conn, address = server_socket.accept()

    serialized_commands = conn.recv(1024).decode('utf-8')
    if not serialized_commands:
        conn.close()
    commands = json.loads(serialized_commands)
    response_list = communicate_with_board(commands)

    response = []
    for el in range(len(response_list)):
        if response_list[el] < 0:
            response.append(el)

    conn.send(json.dumps(response).encode('utf-8'))

    conn.close()


if __name__ == '__main__':
    server_program()
