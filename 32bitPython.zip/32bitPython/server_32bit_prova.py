import json
import socket
from ad5361_commands import ad5361


def communicate_with_board(command):
    board = ad5361()
    try:
        response = board.Write_Voltage(command[0], command[1])
        board.Pulse_LDAC()
        return response
    except Exception as e:
        return e


def server_program():
    host = '127.0.0.1'  # IP locale
    port = 65432        # Porta su cui ascoltare

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))  # Associa l'indirizzo IP e la porta
    server_socket.listen(1)  # Massimo 1 connessione attiva alla volta
    print("Server (32-bit) in attesa di connessioni...")

    conn, address = server_socket.accept()  # Accetta la connessione dal client
    print(f"Connessione stabilita con {address}")

    while True:
        # Ricevi comandi dal client
        serialized_command = conn.recv(1024).decode('utf-8')
        if not serialized_command:
            break
        command = json.loads(serialized_command)
        print(f"Ricevuto comando: {command}")

        # Esegui la comunicazione con la scheda
        response = communicate_with_board(command)

        # Invia la risposta al client
        conn.send(response.encode('utf-8'))

    conn.close()  # Chiude la connessione
    print("Connessione chiusa")


if __name__ == '__main__':
    server_program()
