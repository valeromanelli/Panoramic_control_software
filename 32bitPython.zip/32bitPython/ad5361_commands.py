from ctypes import *
from array import array


HEX_PATH = "C:/Users/Panoramic/PycharmProjects/32bitPython/attachments/Drivers/AD536xSPI.hex".encode("utf-8")
DLL_PATH = "C:/Users/Panoramic/PycharmProjects/32bitPython/attachments/DLL Sample VIs/ADI_CYUSB_USB4.dll"

class ad5361:
    """ Class to control the AD537x EVAL board. """
    def __init__(self, vid=1110, pid=45582):
        self.dll = windll.LoadLibrary(DLL_PATH)
        self.VID = vid
        self.PID = pid
        self.handle = c_uint(0)
        self.hexfile = array('B', HEX_PATH)
        self.hexfile.append(0)
        if not self.Connect_to_Board():
            print("Connected to board...")
            print("Writing offset values")
            self.Write_SPI_Word('022000') #Write offset values to get +- 10V span
            self.Pulse_LDAC()
            self.Write_SPI_Word('032000') #Write offset values to get +- 10V span
            self.Pulse_LDAC()
            for i in range(16):
                self.Write_Voltage(0, i) # Zero all channels
            self.Pulse_LDAC()
            print("done. Ready to use.")
        else:
            print("Could not connect to board, please check your settings.")


    def Connect_to_Board(self, num_boards=1):
        """ Finds the EVAL board, connects to it and uploads the SPI firmware."""

        part_path = create_string_buffer(b"", 8)
        c_vid = c_uint(self.VID)
        c_pid = c_uint(self.PID)
        num = c_uint(num_boards)

        ret_search = self.dll.Search_For_Boards(c_vid, c_pid, byref(num), byref(part_path))

        new_path = part_path.value[0]  # get first value, since there is only one board
        path = c_byte(new_path)
        ret_conn = self.dll.Connect(c_vid, c_pid, path, byref(self.handle))

        arr = (c_int8 * len(self.hexfile))(*self.hexfile)
        ret_firm = self.dll.Download_Firmware(self.handle, arr)

        ret_init = self.Initialise()
        if ret_search != 0 or ret_conn != 0 or ret_firm != 0 or ret_init != 0:
            return 1
        else:
            return 0

    def Write_Voltage(self, Vtarget, channel):
        """ Takes a target voltage and channel and converts it to the correct hex word
        to write to the SPI. """
        index = self.channel_to_hex(channel)
        value = self.voltage_to_hex(Vtarget)
        word = index + value
        return self.Write_SPI_Word(word)


    def Write_SPI_Word(self, word):
        """ Write SPI word by calling the Vendor_Request DLL call. Takes a hexadecimal word
        and splits to different value and index parameters.
        Function prototype: Int Vendor_Request(UInt  Handle, UChar Request, UShort Value, UShort Index,
                            UChar Direction, UShort DataLength, UChar *Buffer[]);
        """
        request = c_uint(int('DD', 16))
        value = int(word[2:6], 16)
        index = int(word[0:2], 16)
        c_index = c_short(index)
        c_value = c_short(value)
        c_zero = c_short(0)
        c_direction = c_char(b'0')
        c_buffer = create_string_buffer(b"", 0)
        ret = self.dll.Vendor_Request(self.handle, request, c_value, c_index, c_direction, c_zero, byref(c_buffer))
        return ret


    def Pulse_LDAC(self):
        """ Pulse LDAC. """
        c_req = c_uint(int('DE', 16))
        c_zero = c_short(0)
        c_buffer = create_string_buffer(b"", 0)
        c_direction = c_char(b'0')
        ret = self.dll.Vendor_Request(self.handle, c_req, c_zero, c_zero, c_direction, c_zero, byref(c_buffer))
        return ret


    def Initialise(self):
        """ Call initialise function after the firmware has been downloaded.
        Thanks dpersechini for pointing this out. """
        request = c_ubyte(int('E0', 16))
        c_zero = c_short(0)
        c_direction = c_char(b'0')
        c_buffer = create_string_buffer(b"", 0)
        ret = self.dll.Vendor_Request(self.handle, request, c_zero, c_zero, c_direction, c_zero, byref(c_buffer))
        return ret


    def voltage_to_hex(self, Vtarget, Vmax=10, Vmin=-10):
        """ Takes target voltage and returns the hexadecimal value for the DAC.
        Default values span from Vmax = 10, Vmin = -10."""
        Vtarget = float(Vtarget)
        Voffset = (Vmax - Vmin) / 2
        x = ((Vtarget + Voffset) / (Vmax - Vmin)) * 65535
        return format(int(round(x)), '04x')


    def num_to_binary(self, num, width=3):
        """ Returns binary string of fixed width from an integer. Default width is 3. """
        bin_code = int("{0:b}".format(num))
        return format(bin_code, '0%dd' % width)


    def channel_to_hex(self, channel):
        if channel < 8:
            group = 1
        else:
            group = 2
            channel -= 8
        group = self.num_to_binary(group)
        channel = self.num_to_binary(channel)
        register = '11'  # Write to X register
        word = register + group + channel
        return format(int(word, 2), '02x')


    def kill(self):
        return self.dll.Disconnect(self.handle)


# Testing
"""if __name__ == '__main__':
    dac = ad5372()
    print(dac.Write_Voltage(0.0725, 0),
          dac.Write_Voltage(0.0726, 1),
            dac.Write_Voltage(0.0725, 2),
            dac.Write_Voltage(0.0735, 3),
            dac.Write_Voltage(0.0745, 4),
            dac.Write_Voltage(0.0755, 5),
            dac.Write_Voltage(0.0825, 6),
            dac.Write_Voltage(0.0925, 7),
            dac.Write_Voltage(0.1725, 8),
            dac.Write_Voltage(0.2725, 9),
            dac.Write_Voltage(1.15, 10),
            dac.Write_Voltage(1.2, 11),
            dac.Write_Voltage(1.225, 12),
            dac.Write_Voltage(1.3, 13),
            dac.Write_Voltage(0.987, 14),
            dac.Write_Voltage(0.856, 15),
            dac.Pulse_LDAC())
    #print(dac.Write_SPI_Word('C80000'))  # Channel 0 = -10V
    #print(dac.Pulse_LDAC())
    # print dac.Write_SPI_Word('C9FFFF')
    # print dac.Pulse_LDAC()
    dac.kill()"""